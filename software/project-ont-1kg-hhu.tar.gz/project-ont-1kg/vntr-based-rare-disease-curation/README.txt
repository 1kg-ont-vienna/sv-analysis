This directory contains the literature-based curation of four VNTR associated diseases. From literature review, we obtained 4 disease associated VNTRs and investigated the diversity of the VNTRs in this study's data.

For more details, refer to notes.md which has notes (some directly taken from the papers)