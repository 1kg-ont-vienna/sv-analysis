# WhatsHap Genotype parameter tweaking

## Idea

- Look at the two parameters: window size and the indel flag.
- Produce Genotypes for the sample HG01258 (overlaps with the pangenome graph)
- Evaluate the result using genotype concordance. Genotype concordance is calculated against the genotype from the graph

