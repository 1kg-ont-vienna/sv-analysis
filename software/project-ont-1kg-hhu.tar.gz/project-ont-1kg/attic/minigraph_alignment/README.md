# Minigraph Alignment

- Aligns reads to chm13-90c.r518.gfa
- Post processes the GAF:
    - haplotagging
    - sorting
