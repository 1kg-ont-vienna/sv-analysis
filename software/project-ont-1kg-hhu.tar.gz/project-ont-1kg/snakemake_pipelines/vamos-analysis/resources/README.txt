vamos-sites-list.bed.gz
GRCh38 based coordinates obtained from Miller Lab

vamos.effMotifs-0.1.T2T-CHM13.tsv.gz
T2T based coordinates obtained from https://zenodo.org/records/13263615