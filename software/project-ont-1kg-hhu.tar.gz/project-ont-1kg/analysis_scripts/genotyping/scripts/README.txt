This folder contains the auxilary scripts outside the snakemake pipeline for some data analysis and plotting.
