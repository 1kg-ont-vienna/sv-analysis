.. include:: README.rst

Table of Contents
-----------------

.. toctree::
   :maxdepth: 2

   installation
   guide
   develop
   changes
