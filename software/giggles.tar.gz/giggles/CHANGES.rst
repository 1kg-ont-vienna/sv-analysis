=======
Changes
=======

v1.0 (2023-07-14)
-----------------

* First working version!
* Supports BAM and GAF alignments.
* Supports edit distance and wavefront alignment for realignment
* Supports `whatshap haplotag` TSV files for restricting model
* Reduced runtime for forward-backward calculation (courtesy: Dr. Mikko Rautiainen and Dr. Jana Ebler)