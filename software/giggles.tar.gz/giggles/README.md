# Giggles

Giggles is a software for genome-wide genotyping using long read sequencing data and a pangenome referenece. Giggles is being developed in the Marschall Lab at the Heinrich Heine University in Duesseldorf.

Details are currently hosted in the GitHub Wiki.

Giggles was developed with [WhatsHap's](https://github.com/whatshap/whatshap) genotype subcommand as the base code and changes were made to incorporate the HMM model and compatibility with GAF and GFA files. For scripts taken directly from WhatsHap or modified, it has been explicitly stated at the top of the scripts.